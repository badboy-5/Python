class PassengerUserException(Exception):
    pass