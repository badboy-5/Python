class ticketConfigException(Exception):
    pass