class balanceException(Exception):
    pass