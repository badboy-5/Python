class UserPasswordException(Exception):
    pass