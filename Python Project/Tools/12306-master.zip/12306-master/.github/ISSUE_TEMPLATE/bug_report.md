---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**描述问题**
```
A clear and concise description of what the bug is.
```
**重现步骤**
```
步骤一
```
**截图&日志**

**环境信息**
 - windows
 - python3.7.1
 - 订票小助手版本 1.1.101

**额外的备注**
- Add any other context about the problem here.
